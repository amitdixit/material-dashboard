import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { MaterialAppModule } from './ngmaterial.module';
import { AppRoutingModule } from './app.routing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


@NgModule({
  declarations: [
    AppComponent,
    // FooterComponent,
    // HeaderComponent
    // , SidebarComponent

  ],
  imports: [
    BrowserModule
    , BrowserAnimationsModule
    , MaterialAppModule
    , AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
