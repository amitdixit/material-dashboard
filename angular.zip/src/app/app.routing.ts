import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';



const routes: Routes = [
  // {
  //     path: '',
  //     loadChildren: './layouts/admin-layout.module#AdminLayoutModule',
  //     canActivate: [AuthGuard]
  // },
  // { path: 'login', loadChildren: './login/login.module#LoginModule' },
  // { path: 'signup', loadChildren: './signup/signup.module#SignupModule' },
  // { path: 'not-found', loadChildren: './not-found/not-found.module#NotFoundModule' },
  {
    path: '',
    loadChildren: './shared/shared.module#SharedModule',
   // canActivate: [AuthGuard]
  },
  { path: '**', redirectTo: '404' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
