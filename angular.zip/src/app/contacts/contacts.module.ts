import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactsComponent } from './contacts.component';
import { ContactsRoutes } from './contacts.routing';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    CommonModule
    ,    RouterModule.forChild(ContactsRoutes),

  ],
  declarations: [ContactsComponent]
})
export class ContactsModule { }
