import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { DashboardRoutes } from './dashboard.routing';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MaterialAppModule } from '../ngmaterial.module';

import { ChartsModule } from 'ng2-charts';
import { DashboardComponent, LineChartComponent, BarChartComponent, PieChartComponent, DoughnutChartComponent } from 'src/app/dashboard';

// import { DashboardComponent } from './dashboard.component';
// import { LineChartComponent } from './line-chart/line-chart.component';
// import { BarChartComponent } from './bar-chart/bar-chart.component';
// import { PieChartComponent } from './pie-chart/pie-chart.component';
// import { DoughnutChartComponent } from './doughnut-chart/doughnut-chart.component';


@NgModule({
  imports: [
    CommonModule
    , RouterModule.forChild(DashboardRoutes)
   , ChartsModule
   , MaterialAppModule
   , FlexLayoutModule
  ],
  declarations: [DashboardComponent, LineChartComponent, BarChartComponent, PieChartComponent, DoughnutChartComponent]
})
export class DashboardModule { }
