import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {  MatButtonModule, MatToolbarModule , MatCardModule, MatMenuModule, MatIconModule
  , MatInputModule, MatProgressSpinnerModule, MatSidenavModule, MatListModule, MatGridListModule, MatProgressBarModule
  } from '@angular/material';
import { LayoutModule } from '@angular/cdk/layout';


@NgModule({
  imports: [
   //  BrowserAnimationsModule
     LayoutModule
    , MatButtonModule
    , MatToolbarModule
    , MatCardModule
    , MatMenuModule
    , MatIconModule
    , MatInputModule
    , MatProgressSpinnerModule
    , MatSidenavModule
    , MatListModule
    , MatGridListModule
    , MatProgressBarModule

  ],
  exports: [
      MatButtonModule
    , LayoutModule
    , MatToolbarModule
    , MatCardModule
    , MatMenuModule
    , MatIconModule
    , MatInputModule
    , MatProgressSpinnerModule
    , MatSidenavModule
    , MatListModule
    , MatGridListModule
  ]
})
export class MaterialAppModule { }
