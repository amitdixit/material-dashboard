import { Injectable } from '@angular/core';

export interface BadgeItem {
  type: string;
  value: string;
}

export interface ChildrenItems {
  state: string;
  name: string;
  type?: string;
}

export interface Menu {
  state: string;
  name: string;
  type: string;
  icon: string;
  badge?: BadgeItem[];
  children?: ChildrenItems[];
}
// contacts
const MENUITEMS = [
  {
    state: 'dashboard',
    name: 'DASHBOARD',
    type: 'link',
    icon: 'dashboard'
  },
   {
     state: 'users',
     name: 'USERS',
     type: 'link',
     icon: 'supervised_user_circle'
   }
   ,
   {
     state: 'contact',
     name: 'CONTACTS',
     type: 'link',
     icon: 'perm_media'
   }
   ,
   {
     state: 'contact',
     name: 'MESSAGE',
     type: 'link',
     icon: 'message'
   }
];

@Injectable()
export class MenuItems {
  getAll(): Menu[] {

    return MENUITEMS;
  }

  add(menu: Menu) {

    MENUITEMS.push(menu);
  }
}
