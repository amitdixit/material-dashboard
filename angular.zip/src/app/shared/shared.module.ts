import { NgModule } from '@angular/core';
import { MenuItems } from './layout/menu-items/menu-items';
import { SharedLayoutRoutingModule } from './shared.routing';
import { SidebarComponent, HeaderComponent } from './layout';
import { MaterialAppModule } from '../ngmaterial.module';
import { CommonModule } from '@angular/common';



@NgModule({
  imports: [
    SharedLayoutRoutingModule
    , MaterialAppModule
     , CommonModule
  ],
  exports: [],
  declarations: [
     SidebarComponent
     , HeaderComponent]
     ,
  providers: [ MenuItems ]
})
export class SharedModule { }
