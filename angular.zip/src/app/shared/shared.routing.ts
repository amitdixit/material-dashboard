import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SidebarComponent } from './layout';


const routes: Routes = [
  {
    path: '', component: SidebarComponent,
    children: [{
      path: 'dashboard',
      loadChildren: '../dashboard/dashboard.module#DashboardModule',
    }
    , {
       path: 'users',
       loadChildren: '../users/users.module#UsersModule'
     }
    , {
      path: 'contact',
      loadChildren: '../contacts/contacts.module#ContactsModule'
    }
  ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SharedLayoutRoutingModule { }
