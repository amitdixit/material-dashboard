import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  users: Users[] = [
    { id: 18, name: 'Dr IQ', pictureurl: '/src/assets/images/pics/4.jpg' },
    { id: 12, name: 'Narco', pictureurl: '/src/assets/images/pics/2.jpg' },
    { id: 11, name: 'Mr. Nice', pictureurl: '/src/assets/images/pics/1.jpg' },
    { id: 13, name: 'Bombasto', pictureurl: '/src/assets/images/pics/3.jpg' },
    { id: 14, name: 'Celeritas', pictureurl: '/src/assets/images/pics/5.jpg' },
    { id: 15, name: 'Magneta', pictureurl: '/src/assets/images/pics/6.jpg' },
    { id: 16, name: 'RubberMan', pictureurl: '/src/assets/images/pics/4.jpg' },
    { id: 17, name: 'Dynama', pictureurl: '/src/assets/images/pics/2.jpg' },
    { id: 19, name: 'Magma', pictureurl: '/src/assets/images/pics/3.jpg' },
    { id: 20, name: 'Tornado', pictureurl: '/src/assets/images/pics/1.jpg' }
  ];


  constructor() { }

  ngOnInit() {
  }

}


export class Users {
  id: number;
  name: string;
  pictureurl: string;
}
