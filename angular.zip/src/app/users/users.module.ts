import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsersComponent } from './users.component';
import { RouterModule } from '@angular/router';
import { UsersRoutes } from './users.routing';
import { MaterialAppModule } from '../ngmaterial.module';
import { FlexLayoutModule } from '../../../node_modules/@angular/flex-layout';


@NgModule({
  imports: [
    CommonModule
    , RouterModule.forChild(UsersRoutes)
    , MaterialAppModule
    , FlexLayoutModule

  ],
  declarations: [UsersComponent]
})
export class UsersModule { }
