require('./angular-mocks');
module.exports = 'ngMock';
